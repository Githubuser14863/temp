#include <iostream>
#include <vector>
#include <omp.h>

int main()
{
    const int N = 100;            // number of elements in array
    const int n = 5;              // number of threads/processors
    std::vector<int> array(N, 1); // Array initialized with 1s

    int sum = 0;

    omp_set_num_threads(n);
#pragma omp parallel
    {
        int local_sum = 0;
#pragma omp for
        for (int i = 0; i < N; i++)
        {
            local_sum += array[i];
        }
#pragma omp critical
        {
            sum += local_sum;
            std::cout << "Intermediate sum calculated at processor " << omp_get_thread_num()
                      << ": " << local_sum << "\n";
        }
    }

    std::cout << "Final sum: " << sum << "\n";

    return 0;
}

// g++ -fopenmp -o sum openmp.cpp