import java.io.*;
import java.net.*;

public class TokenRingClient {
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;

    public void startConnection(String ip, int port) {
        try {
            clientSocket = new Socket(ip, port);
            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendMessage(String msg) {
        out.println(msg);
    }

    public String receiveMessage() {
        try {
            return in.readLine();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) throws IOException {
        TokenRingClient client1 = new TokenRingClient();
        client1.startConnection("127.0.0.1", 6666);

        BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));

        while(true) {
            String token = client1.receiveMessage();
            if(token != null) {
                System.out.println("Received Token: " + token);

                // critical section
                System.out.println("Entering critical section. Type your message: ");
                String message = userInput.readLine(); // read message from user
                client1.sendMessage(message);
                System.out.println("Message sent: " + message);
                System.out.println("Exiting critical section");

                client1.sendMessage("Token used");
            }
        }
    }
}
