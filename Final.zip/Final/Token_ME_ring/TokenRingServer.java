import java.io.*;
import java.net.*;

public class TokenRingServer {
    private ServerSocket serverSocket;
    private Socket clientSocket1, clientSocket2;
    private PrintWriter out1, out2;
    private BufferedReader in1, in2;

    public void start(int port) {
        try {
            serverSocket = new ServerSocket(port);
            clientSocket1 = serverSocket.accept();
            out1 = new PrintWriter(clientSocket1.getOutputStream(), true);
            in1 = new BufferedReader(new InputStreamReader(clientSocket1.getInputStream()));

            clientSocket2 = serverSocket.accept();
            out2 = new PrintWriter(clientSocket2.getOutputStream(), true);
            in2 = new BufferedReader(new InputStreamReader(clientSocket2.getInputStream()));

            String token = "token";
            while (true) {
                out1.println(token);
                String message1 = in1.readLine();
                System.out.println("Received: " + message1);
                in1.readLine(); // read "Token used"

                out2.println(token);
                String message2 = in2.readLine();
                System.out.println("Received: " + message2);
                in2.readLine(); // read "Token used"
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void stop() {
        try {
            in1.close();
            out1.close();
            clientSocket1.close();
            in2.close();
            out2.close();
            clientSocket2.close();
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        TokenRingServer server = new TokenRingServer();
        server.start(6666);
    }
}
