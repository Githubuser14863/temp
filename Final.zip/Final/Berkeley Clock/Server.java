import java.io.*;
import java.net.*;
import java.util.*;

public class Server {

    static int serverPort = 12345;
    static List<Long> clientTimes = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        System.out.println("Server is starting...");
        try (ServerSocket serverSocket = new ServerSocket(serverPort)) {
            System.out.println("Server is listening on port " + serverPort);

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New client connected");

                new ServerThread(socket).start();
            }
        }
    }
}

class ServerThread extends Thread {
    private Socket socket;

    public ServerThread(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        System.out.println("Server thread started for client...");
        try {
            InputStream input = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));

            long clientTime = Long.parseLong(reader.readLine());
            System.out.println("Received client time: " + clientTime);
            Server.clientTimes.add(clientTime);

            long averageTime = getAverageTime(Server.clientTimes);
            System.out.println("Calculated average time: " + averageTime);

            OutputStream output = socket.getOutputStream();
            PrintWriter writer = new PrintWriter(output, true);
            writer.println(averageTime);
            System.out.println("Sent average time to client.");

        } catch (IOException ex) {
            System.out.println("Server exception: " + ex.getMessage());
        }
    }

    private long getAverageTime(List<Long> times) {
        long sum = 0;
        for (Long time : times) {
            sum += time;
        }
        return sum / times.size();
    }
}
