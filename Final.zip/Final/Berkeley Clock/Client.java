import java.io.*;
import java.net.*;

public class Client {

    static String hostname = "localhost";
    static int port = 12345;

    public static void main(String[] args) {
        System.out.println("Client is starting...");
        try (Socket socket = new Socket(hostname, port)) {

            // Send current time to server
            OutputStream output = socket.getOutputStream();
            PrintWriter writer = new PrintWriter(output, true);

            long currentTime = System.currentTimeMillis();
            System.out.println("Sending current time to server: " + currentTime);
            writer.println(currentTime);

            // Receive average time from server and adjust clock
            InputStream input = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            long newTime = Long.parseLong(reader.readLine());

            System.out.println("Received average time from server, setting clock to: " + newTime);
            // This is a simulation. In a real situation, you would need to adjust the system clock.
        } catch (UnknownHostException ex) {
            System.out.println("Server not found: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("I/O error: " + ex.getMessage());
        }
    }
}

