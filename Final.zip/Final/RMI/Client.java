import java.rmi.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try{
            Scanner sc = new Scanner(System.in);
            ServerInterface si = (ServerInterface) Naming.lookup("rmi://localhost/Server");
            System.out.println("Enter a");
            String a = sc.nextLine();
            System.out.println("Enter b");
            String b = sc.nextLine();
            System.out.println("Result "+ si.concat(a,b));
            sc.close();
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }

    }
}
