import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class RingAlgorithm {
    List<Node> nodes;

    public RingAlgorithm(int numOfNodes) {
        this.nodes = new ArrayList<>();
        for (int i = 0; i < numOfNodes; i++) {
            nodes.add(new Node(i));
        }
    }

    public Node electLeader() {
        Node leader = nodes.get(0);
        for (Node node : nodes) {
            if (node.active) {
                System.out.println("Node " + node.id + " passes token");
                leader = node;
            }
        }
        System.out.println("Leader is Node " + leader.id);
        return leader;
    }
}

public class Ring {
    public static void main(String[] args) {
        RingAlgorithm ringAlgorithm = new RingAlgorithm(5);
        ringAlgorithm.electLeader();

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Enter the id of the node you want to change the status of (or -1 to quit):");
            int id = scanner.nextInt();
            if (id == -1) {
                break;
            } else if (id >= 0 && id < ringAlgorithm.nodes.size()) {
                Node node = ringAlgorithm.nodes.get(id);
                node.setActive(!node.isActive());
                System.out.println("Node " + id + " is now " + (node.isActive() ? "active" : "inactive"));
                ringAlgorithm.electLeader();
            } else {
                System.out.println("Invalid id. Please enter a number between 0 and " + (ringAlgorithm.nodes.size() - 1));
            }
        }
        scanner.close();
    }
}
