import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Node {
    int id;
    boolean active;

    public Node(int id) {
        this.id = id;
        this.active = true;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isActive() {
        return this.active;
    }
}

class BullyAlgorithm {
    List<Node> nodes;

    public BullyAlgorithm(int numOfNodes) {
        this.nodes = new ArrayList<>();
        for (int i = 0; i < numOfNodes; i++) {
            nodes.add(new Node(i));
        }
    }

    public Node electLeader() {
        Node leader = null;
        for (Node node : nodes) {
            if (node.active && (leader == null || node.id > leader.id)) {
                leader = node;
            }
        }
        System.out.println("Leader is Node " + leader.id);
        return leader;
    }
}

public class Bully {
    public static void main(String[] args) {
        BullyAlgorithm bullyAlgorithm = new BullyAlgorithm(5);
        bullyAlgorithm.electLeader();

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Enter the id of the node you want to change the status of (or -1 to quit):");
            int id = scanner.nextInt();
            if (id == -1) {
                break;
            } else if (id >= 0 && id < bullyAlgorithm.nodes.size()) {
                Node node = bullyAlgorithm.nodes.get(id);
                node.setActive(!node.isActive());
                System.out.println("Node " + id + " is now " + (node.isActive() ? "active" : "inactive"));
                bullyAlgorithm.electLeader();
            } else {
                System.out.println("Invalid id. Please enter a number between 0 and " + (bullyAlgorithm.nodes.size() - 1));
            }
        }
        scanner.close();
    }
}
